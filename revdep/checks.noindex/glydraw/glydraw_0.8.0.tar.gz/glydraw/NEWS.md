# glydraw 0.8.0

## Breaking changes

* Cartoon appearance is now configured with `style = style_glydraw(...)` across `draw_cartoon()`, `glycanGrob()`, `geom_glycan()`, `guide_glycan()`, `scale_x_glycan()`, `scale_y_glycan()`, `anno_glycan()`, and `export_cartoons()`; calls that pass `fuc_orient`, `edge_linewidth`, `node_linewidth`, `node_size`, `font_family`, or `colors` directly should move those arguments into `style_glydraw()`. `show_linkage` and `orient` remain explicit arguments and are no longer accepted by `style_glydraw()`, while explicit `red_end` overrides the reusable style value. (#73, #79)
* `colors` now accepts a complete SNFG palette in the format returned by `glydraw_colors()`; sparse monosaccharide overrides are no longer supported. (#72)
* `glydraw_style()` has been renamed to `style_glydraw()` and is no longer exported; replace calls to `glydraw_style()` with `style_glydraw()`. (#73)
* `orient` no longer accepts `"H"` or `"V"`; calls using them now error and should replace `"H"` with `"left"` and `"V"` with `"up"`. (#68)
* `red_end` in `style_glydraw()`, `style_glygen()`, `style_snfg()`, and `style_glycoworkbench()` must now be a string. Set `red_end_length = 0` to omit the reducing-end line and ignore any `red_end` wave or custom text while retaining its axis-aligned core anomer annotation. Explicit `red_end = NULL` on drawing interfaces continues to inherit `red_end` from `style`. (#80)

## New features

* `anno_glycan()` uses glycan cartoons as row or column labels in ComplexHeatmap heatmaps, with clustering-aware ordering and the sizing, anchoring, rotation, nudging, and styling controls of glycan axis scales. (#67)
* `draw_cartoon_sketch()` draws hand-sketched glycan cartoons with reproducible rough strokes, patterned residue fills, optional drawing media, and the same layout, annotation, orientation, highlighting, styling, sizing, and saving behavior as `draw_cartoon()`. Sketch cartoons always use their handwriting font, ignoring `font_family` in style presets. (#77, #81)
* `font_family` style option controls the font used for text annotations across glycan cartoons, including alpha and beta anomer labels. (#69)
* `geom_glycan()` and `geom_node_glycan()` gain an `alpha` aesthetic. Each cartoon is composited before transparency is applied so nodes continue to occlude the linkage edges beneath them. Graphics devices without alpha-mask and transformation support throw an error for non-opaque values rather than render an inaccurate cartoon. (#85)
* Glycan grobs used by `geom_glycan()`, `geom_node_glycan()`, `guide_glycan()`, `scale_x_glycan()`, and `scale_y_glycan()` now remain vector graphics at every size when exported to PDF or SVG; `draw_cartoon()` and repeated panel structures also render more efficiently with native grid primitives without changing cartoon layout or appearance. (#64, #65, #66)
* `orient` now accepts `"left"`, `"right"`, `"up"`, and `"down"` to draw glycans in any direction. (#68)
* `red_end` now accepts amino-acid sequences with one tagged glycosite, such as `"ABC<site>D</site>EFG"`. The site is bold and anchored to the reducing end, and the sequence rotates with the glycan orientation. (#78, #82)
* `red_end_length` style option controls the length of the reducing-end line; at `0`, the line and all `red_end` decorations are omitted while the axis-aligned core anomer annotation remains. (#80)
* `red_end_size` style option controls the size of custom `red_end` text without changing the `"~"` wave. (#83)
* `scale_x_glycan()`, `scale_y_glycan()`, and `anno_glycan()` gain an `orient` argument. Its `NULL` default automatically selects a drawing orientation from the displayed axis position or annotation side. Default justification follows compatible position-orientation combinations and centers other combinations. (#84)
* `style_glydraw()` is the reusable interface for tuning cartoon appearance; new `style_glygen()`, `style_snfg()`, and `style_glycoworkbench()` presets support common glycan-drawing conventions. (#73, #79)

## Minor improvements and bug fixes

* `draw_cartoon()` now renders `Hex` residues as smooth, device-native circles across standalone cartoons and embedded glycan grobs. (#76)
* Linkage annotations now move beta labels slightly away from horizontal and skewed edge lines while leaving labels beside vertical edges unchanged, including reducing-end annotations. (#70)
* Linkage-annotation collision handling now ignores the two labels belonging to the same edge, preventing enlarged nodes from unnecessarily reflecting an otherwise collision-free linkage. (#75)
* `style_glydraw(node_size = ...)` now distributes linkage-annotation spacing adjustments across the node-to-label and label-to-label gaps, keeping linkage notation readable with enlarged nodes. (#74)

# glydraw 0.7.0

This version of glydraw introduced some `ggplot2` extensions.

## New features

* New `glydraw_style()` stores reusable glycan rendering options for standalone cartoons, grobs, export, ggplot2 layers, guides, and glycan scales. Explicit rendering arguments override the style. (#55)
* New `geom_glycan()` draws glycan cartoons for individual observations in ggplot2 plots, with support for size, rotation, justification, and cartoon appearance.
* New `geom_node_glycan()` draws glycan cartoons as nodes in ggraph network plots, with automatic node positioning and filtering support. (#61)
* New `guide_glycan()` displays glycan cartoons in ggplot2 legends.
* New `scale_x_glycan()` and `scale_y_glycan()` display glycan cartoons as discrete ggplot2 axis labels.
* New `hjust_red_end()` and `vjust_red_end()` anchor vertical and horizontal cartoons at their reducing ends in `geom_glycan()`, `scale_x_glycan()`, `scale_y_glycan()`, and `guide_glycan()`. `guide_glycan()` also gains `hjust` and `vjust` parameters. Reducing-end justification is the default for scale and guide cartoons along the axis perpendicular to their drawing orientation; `geom_glycan()` remains centered by default. (#54)

## Minor improvements and bug fixes

* `draw_cartoon()` now places double core Fuc branches on opposite sides of the core GlcNAc when linkage positions are unavailable, keeping both connections visible. (#59, #60)
* Recognize bisecting GlcNAc from N-glycan topology when linkage information is unavailable, keeping it centered between the two mannose arms. (#58)
* `draw_cartoon()` now treats generic `dHex` residues as Fuc-like branches, using the same layout and `fuc_orient` behavior as Fuc. (#56)

# glydraw 0.6.3

* First release on CRAN.

# glydraw 0.6.2

## Minor improvements and bug fixes

* Fix nested Fuc-like side-chain layout so xyloglucan-like branches preserve residue order and linkage annotations. (#51)

# glydraw 0.6.1

## Minor improvements and bug fixes

* Fix Fuc-like triangle geometry so triangle bases and apexes align with rectangle node bounds. (#49, #50)

# glydraw 0.6.0

## Breaking changes

* `export_cartoons()` no longer supports `glyexp::experiment()` input, and `glyexp` is no longer a package dependency. (#33)
* Specifying optional arguments in a positional manner is no longer supported. Please use `arg = value` instead. (#40)

## New features

* Add the `colors` parameter to `draw_cartoon()` and `export_cartoons()` for customizing monosaccharide fill colors. (#44)
* Add the `fuc_orient` parameter to `draw_cartoon()` and `export_cartoons()` for choosing whether Fuc triangles always point upward or flex toward their linkage direction. (#42)
* Add the `scale` parameter to `save_cartoon()` and `export_cartoons()` for changing output pixel dimensions while preserving cartoon appearance. (#35)
* Add the `node_size` parameter to `draw_cartoon()` and `export_cartoons()` for scaling residue cartoon sizes. Values larger than `2` are rejected because residues overlap. (#36)
* Add the `edge_linewidth` and `node_linewidth` parameters to `draw_cartoon()` and `export_cartoons()` for customizing linkage line and node border widths. (#34)
* Add the `red_end` parameter to `draw_cartoon()` and `export_cartoons()` for custom reducing-end text or a wavy reducing-end annotation. (#31)

## Minor improvements and bug fixes

* Fix substituent label alignment so horizontal labels are bottom-aligned and vertical labels are left-aligned. (#48)
* Extend Fuc-style branch layout and flexible orientation to additional Fuc-like residues. (#46)
* Fix `draw_cartoon()` for structures with two core Fuc branches and one b1-4 GlcNAc branch, avoiding an igraph vertex-selection error and keeping the b1-4 GlcNAc aligned with the core GlcNAc. (#45)
* Deprecate `dpi` for `save_cartoon()` and `export_cartoons()` because glydraw uses an internal fixed design scale. Supplying `dpi` now warns that the argument is ignored. (#35)
* Keep substituent annotations visible when `show_linkage = FALSE`. (#41)
* Fix diagonal HexNAc linkage annotation offsets when `orient = "V"`. (#43)
* Adjust linkage annotation offsets for diagonal HexNAc links. (#29)

# glydraw 0.5.1

## Minor improvements and bug fixes

* Use SNFG standard colors. (8573759)
* Minor aesthetic adjustments to line width and node size. (427e8d0, 4466f88)

# glydraw 0.5.0

## New features

* Use native ggplot2 theme to manage cartoon size, so `ggview` is no longer dependent. (#27)

## Minor improvements and bug fixes

* Fix overlapping linkage annotations for some glycans. (#21)
* Fix overlapping a1-3 and a1-6 core Fucose residues. (#23)
* Orient reducing end annotation line vertically when `orient = "V"`. (#24)
* Redesign the node coordination layout algorithm to fix inaccurate branch spacing for some glycans. (#26, #28)

# glydraw 0.4.1

## Minor improvements and bug fixes

* Fix substituent annotations in glycan cartoons. (#16)
* Fix reducing-end Fuc orientation in O-Fuc glycans. (#15)
* Make `export_cartoons()` create the output directory when needed. (#17)
* Make `export_cartoons()` use vector names as output filenames when available. (#17)

# glydraw 0.4.0

## Breaking changes

* Remove the `mono_size` parameter of `draw_cartoon()`. (9b05e6c)

## New features

* Add a `highlight` parameter to `draw_cartoon()`. (7e57a54, 3745ec8, c1057ba)
* Add `export_cartoons()` to save multiple glycan structure cartoons to files. (e1ac3c3)

## Minor improvements and bug fixes

* Fix the bug that reducing end annotation was not shown with unknown anomer information. (#12)
* Fix the bug that glycans with only one monosaccharide could not be plotted. (#11)
* Fix the bug that "?" in linkages was not correctly handled. (#9)
* Fix the incorrect reducing end annotation direction in some situations. (#8)
* Fix the bug that glycan structures with multiple branches had incorrect layouts. (2ac4e9f)
* Fix the bug that "png" is not supported in `save_cartoon()`. (fed89b9)
* Fix the bug that structures with generic "NeuAc" and "NeuGc" cannot be plotted. (3b78303)

# glydraw 0.3.1

## Minor improvements and bug fixes

* Update dependency to glyrepr 0.10.0.
* Fix various bugs including illegal character processing, fucose arrangement, and display sizing issues.

# glydraw 0.3.0

## Breaking changes

* Remove the `border_px` and `path` parameters from `save_cartoon()`.

## Minor improvements and bug fixes

* Now we use `ggview` instead of `ggimage` for size fixing, which relies on `rstudioapi::viewer()` to display the plot. You might feel some difference in the display effect, but the SNFG itself keeps the same.

# glydraw 0.2.0

## Breaking changes

* Signature of `draw_cartoon()` is changed into `draw_cartoon(structure, mono_size = 0.2, show_linkage = TRUE, orient = "H", ...)` for better semantics.

## New features

* `draw_cartoon()` now prints fixed-size cartoon (sizes are calculated based on glycan structures) to the plot panel, to provide a unified behavior with `save_cartoon()`.
* Add reducing end annotation to the cartoons (including a short segment and the anomer of the reducing end residue).

## Minor improvements and bug fixes

* Update default aesthetic settings:
  * Make residue size larger.
  * Adjust linkage annotation positions.
  * Add a border to the plot panel.
  * Fix the issue that some linkage annotations are truncated.
* Fix the bug that glycans with only one residue cannot be plotted by `draw_cartoon()`.
* Fix the bug that `path` parameter is mandatory in `save_cartoon()`. Now it is optional, to be in line with `ggplot2::ggsave()`.
* Update documentation of `save_cartoon()` to differentiate it with `ggplot2::ggsave()`.

# glydraw 0.1.0

* First GitHub release.
